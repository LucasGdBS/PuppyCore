from django.apps import AppConfig


class AppPuppyCoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_puppy_core'
